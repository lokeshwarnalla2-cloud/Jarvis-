package com.pillu.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

object JarvisCommandEngine {

    fun execute(context: Context, command: String) {
        val cmd = command.lowercase()

        when {
            cmd.contains("youtube") -> openApp(context, "com.google.android.youtube")
            cmd.contains("instagram") -> openApp(context, "com.instagram.android")
            cmd.contains("whatsapp") -> openApp(context, "com.whatsapp")

            cmd.contains("wifi") -> openSettings(context, Settings.ACTION_WIFI_SETTINGS)
            cmd.contains("bluetooth") -> openSettings(context, Settings.ACTION_BLUETOOTH_SETTINGS)
            cmd.contains("brightness") -> openSettings(context, Settings.ACTION_DISPLAY_SETTINGS)
            cmd.contains("settings") || cmd.contains("setting") ->
                openSettings(context, Settings.ACTION_SETTINGS)

            cmd.contains("call") -> {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            else -> Toast.makeText(
                context, "I don't know this command yet 🤖", Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun openSettings(context: Context, action: String) {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openApp(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show()
        }
    }
}
