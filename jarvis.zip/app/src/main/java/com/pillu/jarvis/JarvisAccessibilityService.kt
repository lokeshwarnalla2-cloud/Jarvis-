package com.pillu.jarvis

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class JarvisAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // JARVIS can inspect the current UI here.
    }

    override fun onInterrupt() {
        Toast.makeText(this, "JARVIS interrupted", Toast.LENGTH_SHORT).show()
    }
}
